import { createContext } from 'react';
export const GenericContext = createContext({} as any);
