import { useContext, useEffect, useState } from 'react';
import { GenericContext } from '../../contexts/GenericContext';
import { GET_TOF } from '../../logic/JSONGET';
import { FormInputKeys } from '../../types';

type ButtonProps = {
    name: FormInputKeys;
    label: string;
    fetchUrl: string;
    setData: React.Dispatch<React.SetStateAction<any>>;
};

export const ButtonFetch = ({
    name,
    label,
    fetchUrl,
    setData,
}: ButtonProps) => {
    const { errors, setErrors } = useContext(GenericContext);

    const [isClicked, setIsClicked] = useState(false);

    const onClickHandler = (e: React.MouseEvent) => {
        e.preventDefault();
        setIsClicked(true);
        console.log(`setClicked ${name} to true`);
    };

    useEffect(() => {
        try {
            if (isClicked) {
                GET_TOF(fetchUrl, setData, true);
                setIsClicked(false);
            }
        } catch (e) {
            let newErrors = { ...errors };
            newErrors[name] = e;
            setErrors(() => newErrors);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isClicked]);

    return (
        <>
            {isClicked ? (
                <button disabled>Loading...</button>
            ) : (
                <button onClick={onClickHandler}>{label}</button>
            )}
        </>
    );
};
