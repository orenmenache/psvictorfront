function HomePage() {
    return (
        <div>
            HOME
        </div>
    );
}

export default HomePage;
